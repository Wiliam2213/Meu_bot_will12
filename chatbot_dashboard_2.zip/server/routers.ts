import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { 
  getChatMessages, 
  addChatMessage, 
  getSalesData, 
  seedSalesData,
  getUserSpreadsheetUploads,
  createSpreadsheetUpload,
  addSpreadsheetData,
  getSpreadsheetData,
  getUserSpreadsheetDataForAI,
  deleteSpreadsheetUpload,
} from "./db";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    getMessages: protectedProcedure.query(async ({ ctx }) => {
      return await getChatMessages(ctx.user.id);
    }),
    sendMessage: protectedProcedure
      .input(z.object({ message: z.string() }))
      .mutation(async ({ ctx, input }) => {
        // Add user message to database
        await addChatMessage(ctx.user.id, "user", input.message);

        // Get chat history for context
        const messages = await getChatMessages(ctx.user.id);
        const conversationHistory: Array<{ role: "user" | "assistant"; content: string }> = messages.map((msg) => ({
          role: msg.role as "user" | "assistant",
          content: msg.content,
        }));

        // Get user's spreadsheet data for AI context
        const spreadsheetData = await getUserSpreadsheetDataForAI(ctx.user.id);
        let dataContext = "";
        if (spreadsheetData.length > 0) {
          dataContext = "\n\nDados do usuário disponíveis:\n";
          for (const sheet of spreadsheetData) {
            dataContext += `\nPlanilha: ${sheet.fileName}\n`;
            dataContext += `Dados: ${JSON.stringify(sheet.data.slice(0, 5))}\n`;
            if (sheet.data.length > 5) {
              dataContext += `... e mais ${sheet.data.length - 5} linhas\n`;
            }
          }
        }

        // Call LLM with conversation history and data context
        try {
          const response = await invokeLLM({
            messages: [
              {
                role: "system" as const,
                content:
                  `Você é um assistente de atendimento ao cliente humanizado e amigável. Responda em português de forma clara e concisa. ${dataContext ? 'Use os dados fornecidos para dar respostas mais contextualizadas e precisas.' : ''}` + dataContext,
              },
              ...conversationHistory,
            ] as any,
          });

          const assistantMessage =
            (typeof response.choices[0]?.message?.content === 'string' ? response.choices[0]?.message?.content : null) || "Desculpe, não consegui processar sua mensagem.";

          // Add assistant response to database
          if (typeof assistantMessage === 'string') {
            await addChatMessage(ctx.user.id, "assistant", assistantMessage);
          }

          return {
            success: true,
            message: typeof assistantMessage === 'string' ? assistantMessage : "Desculpe, ocorreu um erro ao processar sua mensagem.",
          };
        } catch (error) {
          console.error("[Chat] LLM error:", error);
          return {
            success: false,
            message: "Desculpe, ocorreu um erro ao processar sua mensagem.",
          };
        }
      }),
  }),

  dashboard: router({
    getSalesData: publicProcedure.query(async () => {
      const data = await getSalesData();
      if (data.length === 0) {
        await seedSalesData();
        return await getSalesData();
      }
      return data;
    }),
  }),

  spreadsheet: router({
    getUploads: protectedProcedure.query(async ({ ctx }) => {
      return await getUserSpreadsheetUploads(ctx.user.id);
    }),

    uploadData: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        columns: z.array(z.string()),
        rows: z.array(z.record(z.string(), z.any())),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          // Create upload record
          const uploadResult = await createSpreadsheetUpload(
            ctx.user.id,
            input.fileName,
            input.columns,
            input.rows.length
          );

          if (!uploadResult) {
            return {
              success: false,
              message: "Erro ao criar registro de upload",
            };
          }

          // Get the upload ID (last inserted ID)
          const uploads = await getUserSpreadsheetUploads(ctx.user.id);
          const latestUpload = uploads[uploads.length - 1];
          
          if (!latestUpload) {
            return {
              success: false,
              message: "Erro ao recuperar ID do upload",
            };
          }

          // Add data rows
          await addSpreadsheetData(latestUpload.id, input.rows);

          return {
            success: true,
            message: `Planilha "${input.fileName}" enviada com sucesso! ${input.rows.length} linhas foram importadas.`,
            uploadId: latestUpload.id,
          };
        } catch (error) {
          console.error("[Spreadsheet] Upload error:", error);
          return {
            success: false,
            message: "Erro ao fazer upload da planilha",
          };
        }
      }),

    getData: protectedProcedure
      .input(z.object({ uploadId: z.number() }))
      .query(async ({ input, ctx }) => {
        return await getSpreadsheetData(input.uploadId);
      }),

    delete: protectedProcedure
      .input(z.object({ uploadId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const success = await deleteSpreadsheetUpload(input.uploadId);
        return {
          success,
          message: success ? "Planilha deletada com sucesso" : "Erro ao deletar planilha",
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
