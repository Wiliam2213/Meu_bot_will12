import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

import { chatMessages, sales } from "../drizzle/schema";

/**
 * Get chat messages for a user
 */
export async function getChatMessages(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get chat messages: database not available");
    return [];
  }

  try {
    const result = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(chatMessages.createdAt);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get chat messages:", error);
    return [];
  }
}

/**
 * Add a chat message
 */
export async function addChatMessage(
  userId: number,
  role: string,
  content: string
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add chat message: database not available");
    return null;
  }

  try {
    const result = await db.insert(chatMessages).values({
      userId,
      role,
      content,
    });
    return result;
  } catch (error) {
    console.error("[Database] Failed to add chat message:", error);
    return null;
  }
}

/**
 * Get sales data for dashboard
 */
export async function getSalesData() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sales data: database not available");
    return [];
  }

  try {
    const result = await db.select().from(sales);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get sales data:", error);
    return [];
  }
}

/**
 * Add sample sales data (for seeding)
 */
export async function seedSalesData() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot seed sales data: database not available");
    return;
  }

  try {
    const sampleData = [
      {
        date: "2024-01-15",
        product: "Laptop X1",
        category: "Eletrônicos",
        region: "Sudeste",
        quantity: 5,
        unitPrice: "1500.00",
        totalRevenue: "7500.00",
      },
      {
        date: "2024-01-20",
        product: "Monitor 4K",
        category: "Eletrônicos",
        region: "Sul",
        quantity: 3,
        unitPrice: "1200.00",
        totalRevenue: "3600.00",
      },
      {
        date: "2024-02-10",
        product: "Teclado Mecânico",
        category: "Acessórios",
        region: "Nordeste",
        quantity: 8,
        unitPrice: "350.00",
        totalRevenue: "2800.00",
      },
      {
        date: "2024-02-15",
        product: "Mouse Óptico",
        category: "Acessórios",
        region: "Centro-Oeste",
        quantity: 10,
        unitPrice: "150.00",
        totalRevenue: "1500.00",
      },
      {
        date: "2024-03-05",
        product: "Webcam HD",
        category: "Periféricos",
        region: "Norte",
        quantity: 4,
        unitPrice: "400.00",
        totalRevenue: "1600.00",
      },
    ];

    for (const data of sampleData) {
      await db.insert(sales).values(data);
    }
    console.log("[Database] Sales data seeded successfully");
  } catch (error) {
    console.error("[Database] Failed to seed sales data:", error);
  }
}

/**
 * Get user's spreadsheet uploads
 */
export async function getUserSpreadsheetUploads(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get spreadsheet uploads: database not available");
    return [];
  }

  try {
    const { spreadsheetUploads } = await import("../drizzle/schema");
    const result = await db
      .select()
      .from(spreadsheetUploads)
      .where(eq(spreadsheetUploads.userId, userId))
      .orderBy(spreadsheetUploads.createdAt);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get spreadsheet uploads:", error);
    return [];
  }
}

/**
 * Create a spreadsheet upload record
 */
export async function createSpreadsheetUpload(
  userId: number,
  fileName: string,
  columns: string[],
  rowCount: number,
  fileUrl?: string
) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create spreadsheet upload: database not available");
    return null;
  }

  try {
    const { spreadsheetUploads } = await import("../drizzle/schema");
    const result = await db.insert(spreadsheetUploads).values({
      userId,
      fileName,
      columns: JSON.stringify(columns),
      rowCount,
      fileUrl,
    });
    return result;
  } catch (error) {
    console.error("[Database] Failed to create spreadsheet upload:", error);
    return null;
  }
}

/**
 * Add spreadsheet data rows
 */
export async function addSpreadsheetData(uploadId: number, rows: Record<string, unknown>[]) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add spreadsheet data: database not available");
    return null;
  }

  try {
    const { spreadsheetData } = await import("../drizzle/schema");
    const values = rows.map((row) => ({
      uploadId,
      rowData: JSON.stringify(row),
    }));
    const result = await db.insert(spreadsheetData).values(values);
    return result;
  } catch (error) {
    console.error("[Database] Failed to add spreadsheet data:", error);
    return null;
  }
}

/**
 * Get spreadsheet data for an upload
 */
export async function getSpreadsheetData(uploadId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get spreadsheet data: database not available");
    return [];
  }

  try {
    const { spreadsheetData } = await import("../drizzle/schema");
    const result = await db
      .select()
      .from(spreadsheetData)
      .where(eq(spreadsheetData.uploadId, uploadId));
    return result.map((row) => JSON.parse(row.rowData));
  } catch (error) {
    console.error("[Database] Failed to get spreadsheet data:", error);
    return [];
  }
}

/**
 * Get all spreadsheet data for a user (for AI context)
 */
export async function getUserSpreadsheetDataForAI(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user spreadsheet data: database not available");
    return [];
  }

  try {
    const { spreadsheetUploads, spreadsheetData } = await import("../drizzle/schema");
    const uploads = await db
      .select()
      .from(spreadsheetUploads)
      .where(eq(spreadsheetUploads.userId, userId));

    const allData: Array<{ fileName: string; data: Record<string, unknown>[] }> = [];

    for (const upload of uploads) {
      const data = await db
        .select()
        .from(spreadsheetData)
        .where(eq(spreadsheetData.uploadId, upload.id));
      
      allData.push({
        fileName: upload.fileName,
        data: data.map((row) => JSON.parse(row.rowData)),
      });
    }

    return allData;
  } catch (error) {
    console.error("[Database] Failed to get user spreadsheet data:", error);
    return [];
  }
}

/**
 * Delete a spreadsheet upload and its data
 */
export async function deleteSpreadsheetUpload(uploadId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete spreadsheet upload: database not available");
    return false;
  }

  try {
    const { spreadsheetUploads, spreadsheetData } = await import("../drizzle/schema");
    await db.delete(spreadsheetData).where(eq(spreadsheetData.uploadId, uploadId));
    await db.delete(spreadsheetUploads).where(eq(spreadsheetUploads.id, uploadId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete spreadsheet upload:", error);
    return false;
  }
}
