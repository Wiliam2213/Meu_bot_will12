# Guia de Uso - Chatbot e Dashboard Analítico

## Informações do Projeto

**Acesso:** A aplicação está disponível em `http://localhost:3000` durante o desenvolvimento.

**Propósito:** Uma plataforma integrada que combina um assistente de IA humanizado para atendimento ao cliente com um dashboard analítico de vendas em tempo real.

**Acesso:** Requer autenticação via OAuth. Após fazer login, você terá acesso completo ao dashboard e ao chatbot.

---

## Powered by Manus

**Stack Tecnológico:**
- **Frontend:** React 19 + TypeScript + Tailwind CSS 4 + shadcn/ui
- **Backend:** Express.js 4 + tRPC 11 com autenticação OAuth integrada
- **Banco de Dados:** MySQL com Drizzle ORM
- **Integração de IA:** API de LLM configurada e pronta para uso
- **Deployment:** Infraestrutura auto-escalável com CDN global

---

## Usando Sua Aplicação

### 1. Página Inicial

Ao acessar a aplicação, você verá a página inicial com informações sobre as funcionalidades. Se ainda não estiver autenticado, clique em **"Começar Agora"** ou **"Fazer Login"** para se autenticar com segurança.

### 2. Acessar o Dashboard

Após fazer login, clique em **"Ir para Dashboard"** ou **"Acessar Dashboard"** para entrar na área principal da aplicação.

### 3. Dashboard Analítico

O dashboard exibe quatro cards principais com estatísticas:

- **Receita Total:** Soma de todas as vendas registradas no sistema
- **Total de Vendas:** Número total de transações
- **Melhor Região:** Região com maior receita acumulada
- **Produto Top:** Produto mais vendido por receita

A seção de **"Últimas Vendas"** mostra as 5 transações mais recentes com detalhes de produto, categoria, região, quantidade e valor.

### 4. Conversar com o Assistente

No painel direito do dashboard, você encontra o **"Assistente de Atendimento"**. Para conversar:

1. Digite sua mensagem na caixa de texto no final do painel
2. Clique no botão de envio (ícone de seta) ou pressione Enter
3. O assistente responderá em tempo real com respostas humanizadas e contextualizadas
4. Seu histórico de conversa é armazenado e recuperado a cada acesso

### 5. Fazer Logout

Clique em **"Sair"** no canto superior direito para encerrar sua sessão de forma segura.

---

## Gerenciando Sua Aplicação

### Painel de Configurações

Acesse o painel de **Configurações** na interface de gerenciamento para:

- **Geral:** Modificar o título e logo da aplicação
- **Domínios:** Gerenciar domínios customizados ou usar o domínio auto-gerado
- **Banco de Dados:** Acessar a interface de gerenciamento do banco de dados (CRUD)
- **Segredos:** Gerenciar variáveis de ambiente, incluindo a chave de API do LLM

### Dashboard de Análise

O painel de **Dashboard** oferece:

- Visualização de estatísticas de acesso (UV/PV) para sites publicados
- Monitoramento de saúde da aplicação
- Histórico de checkpoints salvos

### Banco de Dados

Acesse a interface de **Banco de Dados** para:

- Visualizar e gerenciar tabelas (`users`, `chat_messages`, `sales`)
- Executar operações CRUD diretamente
- Verificar dados de usuários, conversas e vendas

---

## Próximos Passos

Converse com a IA a qualquer momento para solicitar mudanças, adicionar novas funcionalidades ou relatar problemas. Você pode pedir:

- Novos gráficos ou visualizações de dados
- Funcionalidades adicionais no chatbot
- Alterações no design ou layout
- Integração com outras APIs ou serviços

**Comece agora explorando o dashboard e conversando com o assistente para descobrir todas as possibilidades!**

---

## Notas Técnicas

- As conversas são armazenadas no banco de dados e recuperadas automaticamente
- Os dados de vendas são pré-carregados na primeira execução
- A chave de API do LLM é armazenada com segurança no backend (nunca exposta no frontend)
- Todas as requisições são autenticadas e seguras
