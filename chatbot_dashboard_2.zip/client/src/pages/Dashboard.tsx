import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Send } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch chat messages and sales data
  const { data: chatMessages } = trpc.chat.getMessages.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: salesData } = trpc.dashboard.getSalesData.useQuery();
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();

  // Update messages when fetched from server
  useEffect(() => {
    if (chatMessages) {
      setMessages(chatMessages);
    }
  }, [chatMessages]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    setIsLoading(true);
    const userMessage = inputValue;
    setInputValue("");

    // Add user message to UI immediately
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);

    try {
      const response = await sendMessageMutation.mutateAsync({
        message: userMessage,
      });

      if (response.success) {
        setMessages((prev) => [...prev, { role: "assistant", content: response.message }]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: "Desculpe, ocorreu um erro ao processar sua mensagem." },
        ]);
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Desculpe, ocorreu um erro ao processar sua mensagem." },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Calculate dashboard statistics
  const stats = {
    totalRevenue: salesData?.reduce((sum, sale) => sum + parseFloat(sale.totalRevenue), 0) || 0,
    totalSales: salesData?.length || 0,
    topRegion: salesData
      ? Object.entries(
          salesData.reduce(
            (acc, sale) => {
              acc[sale.region] = (acc[sale.region] || 0) + parseFloat(sale.totalRevenue);
              return acc;
            },
            {} as Record<string, number>
          )
        ).sort(([, a], [, b]) => b - a)[0]?.[0] || "N/A"
      : "N/A",
    topProduct: salesData
      ? Object.entries(
          salesData.reduce(
            (acc, sale) => {
              acc[sale.product] = (acc[sale.product] || 0) + parseFloat(sale.totalRevenue);
              return acc;
            },
            {} as Record<string, number>
          )
        ).sort(([, a], [, b]) => b - a)[0]?.[0] || "N/A"
      : "N/A",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Dashboard Analítico</h1>
          <p className="text-slate-600">
            Bem-vindo, {user?.name || "Usuário"}! Aqui você pode visualizar análises de vendas e conversar com nosso assistente.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Stats Cards */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="bg-white shadow-lg border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-slate-700">Receita Total</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  R$ {stats.totalRevenue.toFixed(2).replace(".", ",")}
                </div>
                <p className="text-xs text-slate-500 mt-1">Todas as vendas</p>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-slate-700">Total de Vendas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{stats.totalSales}</div>
                <p className="text-xs text-slate-500 mt-1">Transações registradas</p>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-slate-700">Melhor Região</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{stats.topRegion}</div>
                <p className="text-xs text-slate-500 mt-1">Maior receita</p>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-lg border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-slate-700">Produto Top</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-lg font-bold text-orange-600 truncate">{stats.topProduct}</div>
                <p className="text-xs text-slate-500 mt-1">Mais vendido</p>
              </CardContent>
            </Card>
          </div>

          {/* Middle Column - Sales Table */}
          <div className="lg:col-span-1">
            <Card className="bg-white shadow-lg border-0 h-full">
              <CardHeader>
                <CardTitle>Últimas Vendas</CardTitle>
                <CardDescription>Transações recentes</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3 pr-4">
                    {salesData && salesData.length > 0 ? (
                      salesData.slice(-5).map((sale, idx) => (
                        <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                          <div className="flex justify-between items-start mb-1">
                            <p className="font-semibold text-sm text-slate-900">{sale.product}</p>
                            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                              {sale.region}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 mb-2">{sale.category}</p>
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-slate-500">Qtd: {sale.quantity}</span>
                            <span className="font-bold text-green-600">
                              R$ {parseFloat(sale.totalRevenue).toFixed(2).replace(".", ",")}
                            </span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-slate-500">Nenhuma venda registrada</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Chat */}
          <div className="lg:col-span-1">
            <Card className="bg-white shadow-lg border-0 h-full flex flex-col">
              <CardHeader>
                <CardTitle>Assistente de Atendimento</CardTitle>
                <CardDescription>Converse com nosso bot humanizado</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col overflow-hidden">
                <ScrollArea className="flex-1 mb-4 pr-4">
                  <div className="space-y-3">
                    {messages.length === 0 ? (
                      <div className="text-center text-slate-500 text-sm py-8">
                        <p>Olá! Como posso ajudá-lo?</p>
                      </div>
                    ) : (
                      messages.map((msg, idx) => (
                        <div
                          key={idx}
                          className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-xs px-4 py-2 rounded-lg text-sm ${
                              msg.role === "user"
                                ? "bg-blue-600 text-white rounded-br-none"
                                : "bg-slate-100 text-slate-900 rounded-bl-none"
                            }`}
                          >
                            {msg.content}
                          </div>
                        </div>
                      ))
                    )}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-slate-100 text-slate-900 px-4 py-2 rounded-lg rounded-bl-none text-sm flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Processando...
                        </div>
                      </div>
                    )}
                    <div ref={scrollRef} />
                  </div>
                </ScrollArea>

                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <Input
                    placeholder="Digite sua mensagem..."
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    disabled={isLoading}
                    className="flex-1"
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !inputValue.trim()}
                    size="icon"
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
