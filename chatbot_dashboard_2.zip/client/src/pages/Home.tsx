import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { ArrowRight, BarChart3, MessageCircle, Zap } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            {APP_LOGO && <img src={APP_LOGO} alt={APP_TITLE} className="w-8 h-8" />}
            <h1 className="text-xl font-bold text-white">{APP_TITLE}</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-slate-300 text-sm">Bem-vindo, {user?.name}!</span>
                <Link href="/dashboard">
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Ir para Dashboard
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <Button variant="outline" onClick={logout} className="border-slate-600 text-slate-300 hover:bg-slate-800">
                  Sair
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Fazer Login
                </Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Chatbot Inteligente + Dashboard Analítico
          </h2>
          <p className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto">
            Uma solução completa para atendimento ao cliente humanizado e análise de vendas em tempo real.
          </p>
          {isAuthenticated ? (
            <Link href="/dashboard">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                Acessar Dashboard
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                Começar Agora
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </a>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                <MessageCircle className="w-6 h-6 text-blue-400" />
              </div>
              <CardTitle className="text-white">Atendimento Humanizado</CardTitle>
              <CardDescription className="text-slate-400">
                Chatbot inteligente com respostas personalizadas
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Assistente de IA treinado para fornecer atendimento ao cliente de forma amigável e eficiente, com histórico de conversas.
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-green-600/20 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-green-400" />
              </div>
              <CardTitle className="text-white">Dashboard Analítico</CardTitle>
              <CardDescription className="text-slate-400">
                Visualize suas métricas de vendas em tempo real
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Acompanhe receita, produtos mais vendidos, regiões com melhor desempenho e muito mais com dados atualizados.
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-600/20 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-purple-400" />
              </div>
              <CardTitle className="text-white">Integração Completa</CardTitle>
              <CardDescription className="text-slate-400">
                Tudo em um único lugar, pronto para usar
              </CardDescription>
            </CardHeader>
            <CardContent className="text-slate-300">
              Backend seguro com autenticação, banco de dados integrado e API de LLM configurada. Sem complicações.
            </CardContent>
          </Card>
        </div>

        {/* How It Works */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-12 mb-20">
          <h3 className="text-3xl font-bold text-white mb-8 text-center">Como Funciona</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-lg">
                1
              </div>
              <h4 className="text-white font-semibold mb-2">Faça Login</h4>
              <p className="text-slate-400">Autentique-se com segurança usando o sistema de OAuth integrado.</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-lg">
                2
              </div>
              <h4 className="text-white font-semibold mb-2">Acesse o Dashboard</h4>
              <p className="text-slate-400">Visualize suas métricas de vendas e converse com o assistente.</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-lg">
                3
              </div>
              <h4 className="text-white font-semibold mb-2">Obtenha Insights</h4>
              <p className="text-slate-400">Receba análises inteligentes e respostas personalizadas em tempo real.</p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Pronto para começar?</h3>
          <p className="text-slate-300 mb-8">Acesse o dashboard e explore todas as funcionalidades agora mesmo.</p>
          {isAuthenticated ? (
            <Link href="/dashboard">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                Ir para Dashboard
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8">
                Fazer Login
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </a>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900/50 mt-20">
        <div className="max-w-7xl mx-auto px-6 py-8 text-center text-slate-400 text-sm">
          <p>© 2024 {APP_TITLE}. Desenvolvido com IA e tecnologia moderna.</p>
        </div>
      </footer>
    </div>
  );
}
