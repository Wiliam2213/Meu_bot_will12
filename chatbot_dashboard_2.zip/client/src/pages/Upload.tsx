import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Upload, Trash2, Eye, ArrowLeft } from "lucide-react";
import { useRef, useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Papa from "papaparse";

export default function UploadPage() {
  const { isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: uploads, refetch } = trpc.spreadsheet.getUploads.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const uploadMutation = trpc.spreadsheet.uploadData.useMutation();
  const deleteMutation = trpc.spreadsheet.delete.useMutation();
  const { data: selectedData } = trpc.spreadsheet.getData.useQuery(
    { uploadId: 0 },
    { enabled: false }
  );

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: async (results: any) => {
          if (results.data && Array.isArray(results.data) && results.data.length > 0) {
            const columns = Object.keys(results.data[0] as Record<string, unknown>);
            const rows = results.data as Record<string, unknown>[];

            try {
              const response = await uploadMutation.mutateAsync({
                fileName: file.name,
                columns,
                rows,
              });

              if (response.success) {
                alert(response.message);
                await refetch();
                if (fileInputRef.current) {
                  fileInputRef.current.value = "";
                }
              }
            } catch (error) {
              alert("Erro ao fazer upload da planilha");
              console.error(error);
            }
          }
        },
        error: (error: any) => {
          alert("Erro ao processar arquivo: " + error.message);
        },
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (uploadId: number) => {
    if (confirm("Tem certeza que deseja deletar esta planilha?")) {
      try {
        const response = await deleteMutation.mutateAsync({ uploadId });
        if (response.success) {
          alert(response.message);
          await refetch();
        }
      } catch (error) {
        alert("Erro ao deletar planilha");
        console.error(error);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-4 mb-4">
              <Link href="/dashboard">
                <Button variant="outline" size="icon">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
              <h1 className="text-4xl font-bold text-slate-900">Gerenciar Planilhas</h1>
            </div>
            <p className="text-slate-600">
              Faça upload de suas planilhas (CSV ou Excel) para alimentar o dashboard e contextualizar a IA.
            </p>
          </div>
        </div>

        {/* Upload Area */}
        <Card className="bg-white shadow-lg border-0 mb-8">
          <CardHeader>
            <CardTitle>Fazer Upload de Planilha</CardTitle>
            <CardDescription>
              Selecione um arquivo CSV ou Excel para importar dados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileUpload}
                disabled={isLoading}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                className="w-full flex flex-col items-center gap-4"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Upload className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="font-semibold text-slate-900 mb-1">
                    {isLoading ? "Processando..." : "Clique para selecionar um arquivo"}
                  </p>
                  <p className="text-sm text-slate-500">
                    ou arraste um arquivo CSV/Excel aqui
                  </p>
                </div>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Uploaded Files List */}
        <Card className="bg-white shadow-lg border-0">
          <CardHeader>
            <CardTitle>Planilhas Enviadas</CardTitle>
            <CardDescription>
              {uploads && uploads.length > 0
                ? `Você tem ${uploads.length} planilha(s) enviada(s)`
                : "Nenhuma planilha enviada ainda"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {uploads && uploads.length > 0 ? (
              <ScrollArea className="w-full">
                <div className="space-y-3">
                  {uploads.map((upload) => (
                    <div
                      key={upload.id}
                      className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex-1">
                        <p className="font-semibold text-slate-900">{upload.fileName}</p>
                        <p className="text-sm text-slate-500">
                          {upload.rowCount} linhas • {JSON.parse(upload.columns).length} colunas
                        </p>
                        <p className="text-xs text-slate-400 mt-1">
                          Enviado em {new Date(upload.createdAt).toLocaleDateString("pt-BR", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="text-slate-600 hover:text-blue-600"
                          title="Visualizar dados"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          className="text-slate-600 hover:text-red-600"
                          onClick={() => handleDelete(upload.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="text-center py-12">
                <p className="text-slate-500 mb-4">Nenhuma planilha enviada ainda</p>
                <p className="text-sm text-slate-400">
                  Comece fazendo upload de uma planilha para alimentar o dashboard
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Box */}
        <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-2">💡 Dica</h3>
          <p className="text-sm text-blue-800">
            Depois de fazer upload de uma planilha, o dashboard será atualizado com seus dados e a IA terá acesso a essas informações para dar respostas mais contextualizadas e precisas.
          </p>
        </div>
      </div>
    </div>
  );
}
