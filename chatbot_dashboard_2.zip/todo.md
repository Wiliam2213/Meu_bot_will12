# Chatbot Dashboard - TODO

## Funcionalidades Principais

- [x] Backend para chatbot com integração da API de LLM
- [x] Interface do chatbot com histórico de mensagens
- [x] Dashboard analítico de vendas com gráficos
- [x] Página inicial com navegação
- [x] Autenticação e logout
- [x] Responsividade mobile

## Componentes UI

- [x] Chat interface com mensagens
- [x] Dashboard com cards de estatísticas
- [x] Estatísticas de vendas por região
- [x] Produto mais vendido
- [x] Receita total e número de vendas

## Integração Backend

- [x] Procedure tRPC para enviar mensagens ao chatbot
- [x] Procedure tRPC para obter histórico de chat
- [x] Armazenar conversas no banco de dados
- [x] Procedure tRPC para obter dados de vendas
- [x] Procedure tRPC para obter estatísticas

## Novas Funcionalidades Solicitadas

- [ ] Upload de planilhas (CSV/Excel) pelo usuário
- [ ] Página de gerenciamento de uploads
- [ ] Dashboard dinâmico alimentado pelos dados do upload
- [ ] IA contextualizada que usa dados da planilha
- [ ] Armazenamento de múltiplas planilhas por usuário
- [ ] Visualização de dados da planilha no dashboard

## Melhorias Futuras

- [ ] Suporte a múltiplas conversas por usuário
- [ ] Exportar relatórios em PDF
- [ ] Temas claro/escuro alternáveis
- [ ] Notificações em tempo real
- [ ] Gráficos interativos com Chart.js ou Recharts
