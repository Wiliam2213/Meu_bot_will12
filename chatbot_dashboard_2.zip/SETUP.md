# Guia de Inicialização - Chatbot e Dashboard Analítico

## Pré-requisitos

Antes de começar, certifique-se de ter instalado em seu computador:

- **Node.js** (versão 18 ou superior): [https://nodejs.org/](https://nodejs.org/)
- **Git**: [https://git-scm.com/](https://git-scm.com/)
- **VS Code**: [https://code.visualstudio.com/](https://code.visualstudio.com/)

---

## Passo 1: Clonar ou Descompactar o Projeto

### Opção A: Se você recebeu um arquivo ZIP

1. Descompacte o arquivo `chatbot_dashboard.zip` em uma pasta no seu computador
2. Abra o terminal/prompt de comando
3. Navegue até a pasta descompactada:
   ```bash
   cd caminho/para/chatbot_dashboard
   ```

### Opção B: Se você tem um repositório Git

```bash
git clone <url-do-repositorio>
cd chatbot_dashboard
```

---

## Passo 2: Abrir no VS Code

1. Abra o VS Code
2. Vá em **File** (Arquivo) > **Open Folder** (Abrir Pasta)
3. Selecione a pasta `chatbot_dashboard`
4. Aguarde o VS Code indexar os arquivos (pode levar alguns segundos)

---

## Passo 3: Instalar Dependências

1. Abra o terminal integrado do VS Code:
   - Pressione `Ctrl + `` (backtick) ou vá em **Terminal** > **New Terminal**

2. Instale as dependências do projeto:
   ```bash
   npm install
   ```
   
   Ou, se preferir usar `pnpm` (mais rápido):
   ```bash
   pnpm install
   ```

3. Aguarde a conclusão da instalação (pode levar alguns minutos)

---

## Passo 4: Configurar Variáveis de Ambiente

1. Na raiz do projeto, crie um arquivo chamado `.env.local`
2. Adicione as seguintes variáveis (você receberá esses valores do administrador):
   ```
   DATABASE_URL=<sua-url-de-banco-de-dados>
   JWT_SECRET=<seu-jwt-secret>
   CUSTOM_LLM_API_KEY=<sua-chave-de-api-do-llm>
   VITE_APP_ID=<seu-app-id>
   OAUTH_SERVER_URL=<url-do-servidor-oauth>
   VITE_OAUTH_PORTAL_URL=<url-do-portal-oauth>
   OWNER_OPEN_ID=<seu-open-id>
   OWNER_NAME=<seu-nome>
   VITE_APP_TITLE=Chatbot e Dashboard Analítico
   VITE_APP_LOGO=<url-do-logo>
   ```

3. Salve o arquivo

---

## Passo 5: Inicializar o Banco de Dados

1. No terminal, execute:
   ```bash
   npm run db:push
   ```
   
   Ou com `pnpm`:
   ```bash
   pnpm db:push
   ```

2. Isso criará as tabelas necessárias no banco de dados

---

## Passo 6: Iniciar o Servidor de Desenvolvimento

1. No terminal, execute:
   ```bash
   npm run dev
   ```
   
   Ou com `pnpm`:
   ```bash
   pnpm dev
   ```

2. Você verá uma mensagem similar a:
   ```
   Server running on http://localhost:3000
   ```

3. Abra seu navegador e acesse: **http://localhost:3000**

---

## Passo 7: Fazer Login e Acessar o Dashboard

1. Na página inicial, clique em **"Fazer Login"** ou **"Começar Agora"**
2. Autentique-se com suas credenciais
3. Após o login, clique em **"Ir para Dashboard"**
4. Você verá:
   - **Estatísticas de vendas** (receita total, número de vendas, melhor região, produto top)
   - **Últimas vendas** com detalhes de transações
   - **Assistente de IA** para conversar e obter insights

---

## Comandos Úteis

### Desenvolvimento
```bash
npm run dev              # Inicia o servidor de desenvolvimento
npm run build            # Compila o projeto para produção
npm run db:push          # Sincroniza o banco de dados com o schema
npm run db:studio        # Abre o Drizzle Studio para gerenciar o banco
```

### Linting e Formatação
```bash
npm run lint             # Verifica o código com ESLint
npm run format           # Formata o código com Prettier
```

---

## Estrutura do Projeto

```
chatbot_dashboard/
├── client/                  # Frontend (React + Tailwind)
│   ├── src/
│   │   ├── pages/          # Páginas (Home, Dashboard)
│   │   ├── components/     # Componentes reutilizáveis
│   │   ├── lib/            # Utilitários e configurações
│   │   └── App.tsx         # Componente principal
│   └── index.html          # HTML base
├── server/                  # Backend (Express + tRPC)
│   ├── routers.ts          # Definição das APIs (tRPC procedures)
│   ├── db.ts               # Funções de banco de dados
│   └── _core/              # Configurações internas
├── drizzle/                # Schema e migrações do banco
│   └── schema.ts           # Definição das tabelas
├── .env.local              # Variáveis de ambiente (não commitar)
└── package.json            # Dependências do projeto
```

---

## Solução de Problemas

### Erro: "Port 3000 is already in use"
Se a porta 3000 já está em uso, você pode:
1. Matar o processo que está usando a porta
2. Ou iniciar em uma porta diferente:
   ```bash
   PORT=3001 npm run dev
   ```

### Erro: "Database connection failed"
Verifique se:
1. A variável `DATABASE_URL` está configurada corretamente em `.env.local`
2. O servidor de banco de dados está rodando
3. As credenciais de acesso estão corretas

### Erro: "Module not found"
Execute novamente:
```bash
npm install
```

### Chatbot não responde
Verifique se:
1. A chave de API do LLM (`CUSTOM_LLM_API_KEY`) está configurada
2. Você está autenticado (fazer login)
3. Verifique o console do navegador (F12) para mensagens de erro

---

## Próximos Passos

1. **Explore o Dashboard:** Veja as estatísticas de vendas e dados em tempo real
2. **Converse com o Assistente:** Teste o chatbot humanizado
3. **Customize:** Modifique cores, textos e funcionalidades conforme necessário
4. **Deploy:** Quando pronto, publique a aplicação (instruções no painel de controle)

---

## Suporte

Se encontrar problemas ou tiver dúvidas:
1. Verifique o console do navegador (F12) para mensagens de erro
2. Verifique o terminal para logs do servidor
3. Consulte a documentação do projeto em `userGuide.md`
4. Solicite ajuda ao administrador do projeto

---

## Bom desenvolvimento! 🚀
